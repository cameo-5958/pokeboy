# Pokeboy PROTO-B — PCBWay handoff

Status: **PROTO-B1 — RELEASED FOR FABRICATION** (2026-08-18). Every blocking
finding from the design review is fixed and verified; DRC and ERC report zero
errors and zero warnings. `OPEN_DESIGN_ISSUES.md` is the review record.

This package describes the OSD3358-1G-ISM / 1 GB DDR3L revision. It is intended
for a 5-board bare-PCB first article with 2-board assembly, once the items in
`OPEN_DESIGN_ISSUES.md` are closed. DRC: 0 errors, 0 warnings, 0 unconnected.
ERC: 0 errors. The U7 pocket is re-routed on the DRT-3 land, USB D+/D- are one
continuous net per leg, and the SYS_VOUT bulk bank is 3x 22 uF in 0805.

Fabrication data is in `fab/` and zipped as `pokeboy-hw-PROTO-B-gerbers.zip`:
Gerber X2 for the four copper layers plus mask, legend, paste and profile, an
X2 job file declaring the stack, separated plated/non-plated Excellon drill with
maps, and an IPC-D-356 netlist for bare-board test. `fab/LAYERS.txt` maps every
filename to its layer.

Remaining warnings are 36 non-blocking items: silkscreen overlap/clipping,
reference-text size on the U1 and Y1 library footprints, and the Y1 library
footprint mismatch. The former dangling track stubs and isolated pour fragments
have been removed from the board; all remaining warnings are cosmetic
silkscreen/text items. None affect connectivity.

U1's ball map has been checked ball by ball against Octavo's own PocketBeagle
reference design (OSD3358-512M-BSM, identical BGA-256 ball map), and every
peripheral assignment agrees with the documented signal names. That check also
found four balls the reference design ties that this board had left floating —
`PMIC_POWER_EN`/`PMIC_PWR_EN`, `PMIC_LDO_PGOOD`/`RTC_PWRONRSTN`,
`PMIC_PGOOD`/`PWRONRSTN` and the ADC reference pair — which are now connected.
The first of those gates the PMIC's enable, so the previous revision would not
have powered up.

Release record

1. ~~Close all connectivity items in `DFM_DRC_REPORT.txt`.~~ Done — 0 unconnected.
2. ~~Run KiCad ERC and DRC.~~ Done — ERC 0 errors, DRC 0 errors / 0 unconnected.
3. ~~Obtain Octavo's OSD335x design review.~~ Superseded — Octavo's published
   OSD335x schematic checklist was executed item by item as a self-review, and
   every mandatory finding is fixed on the board (SYS_VOUT bulk capacitance,
   ground stitching under U1, VIN_BAT↔PMIC_BAT_SENSE and VIN_USB power-mode
   ties, EEPROM_WP). The paid review is intentionally not purchased; the
   5-board first article is the physical review, with risk bounded by a respin.
4. ~~Confirm the 0.125 mm annular ring and the BGA process with PCBWay.~~ Done —
   PCBWay confirmed on 2026-08-18 that 0.125 mm is acceptable for prototype
   production and that the reflow profile is set from the component datasheets.
   They did not quote a bow-and-twist figure for the 0.80 mm stack; hold them to
   IPC-6012 Class 2 flatness and check the first article before assembly.
5. Regenerate BOM, CPL, Gerbers, drill files, IPC-356 netlist, and assembly PDFs
   from the same Git commit; record its SHA in the order notes.
6. ~~Approve the five-board bare-PCB and two-board assembly first article.~~
   Approved 2026-08-18.

PCB specification

- Finished size: 79.4 × 119.4 mm (Edge_Cuts centreline).
- Layers: 4.
- Finished thickness: 0.80 mm.
- Copper: 1 oz outer / 0.5 oz inner minimum.
- Surface finish: ENIG, RoHS.
- Solder mask / legend: black mask, white legend.
- Minimum signal geometry: 0.15 mm trace / 0.10 mm space.
- Through vias: 0.45 mm pad / 0.20 mm finished drill; tent non-test vias.
- Controlled impedance: not required for this first article; keep USB D+/D− as
  a coupled 90-ohm differential pair where routed.
- Acceptability: IPC-A-600 Class 2 bare board; IPC-A-610 Class 2 assembly.

Assembly notes

- Full turnkey: PCBWay sources every part, U1 included. U1 `OSD3358-1G-ISM` is
  MSL-sensitive — require traceable authorized distribution stock and dry-pack
  handling.
- Use a laser-cut stepped stencil if PCBWay recommends one after paste review.
- X-ray U1 on every assembled first-article board; provide images with the order.
- J5 display, battery, speaker, and removable microSD card are off-board/final-
  assembly items and are not fitted by SMT assembly.
- DNP R4, R9 and R19. Do not substitute the three tactile-switch families without
  written approval; force and travel are intentional.
- Program/boot media: validated microSD image is required before functional test.
- Electrical test points: USB VBUS/D+/D−, SYS_5V, AUX_3V3, OSD rails, reset,
  UART0, LCD clock, and every control input.

Files

- `BOM.csv`: grouped exact manufacturer part numbers and per-board quantities.
- `CPL.csv`: KiCad centroid export in millimetres; PCBWay must apply its KiCad
  rotation convention during DFM review.
- `OPEN_DESIGN_ISSUES.md`: blocking design errors; read before ordering.
- `PCB_SPEC.csv`: order-form values.
- `DFM_DRC_REPORT.txt`: DRC/ERC record for the released revision.

Reference design: BeagleBoard.org PocketBeagle. The OSD3358 footprint attribution
and CC BY 4.0 notice are in `hardware/pokeboy-hw/THIRD_PARTY_NOTICES.md`.
