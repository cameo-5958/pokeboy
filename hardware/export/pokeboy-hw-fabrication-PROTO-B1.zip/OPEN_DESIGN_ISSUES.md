# PROTO-B — open design issues

Raised by design review 2026-08-18. The board is on **DESIGN HOLD**: it is not
buildable as it stands. PCBWay's process questions (0.125 mm annular ring,
reflow profile) are closed and are *not* what is blocking.

## Fixed in the source

| # | Issue | Fix applied |
|---|-------|-------------|
| 1 | **U7 footprint was `SOT-23-3`; `TPD2EUSB30DRTR` is a DRT-3 (SOT-5X3) part.** The part could not have been placed. | Footprint changed to `Package_TO_SOT_SMD:Texas_DRT-3` in both schematic and board, nets reattached to pads 1/2/3. **Leaves 6 DRC errors — see A below.** |
| 2 | **J5 was never placed.** The footprint carried `exclude_from_pos_files`, so the 39-pin FFC connector was missing from the CPL, and the BOM line described the display panel instead of the connector. | Flag removed, `J5` value set to `EA WF030-39S`, CPL regenerated (104 placements, was 103). BOM row 53 is now the connector as SMT; the TFT panel is a new off-board row 58. |
| 3 | `.gbrjob` declared **green** solder mask against a black spec. | Board stackup set to Black; regenerate the job file with the gerbers. |
| 4 | MSL handling was mentioned only in `README.md`, not in the assembler-facing files. | Added to `FAB_NOTES.txt` and `PCBWAY_ORDER.md`, referencing J-STD-033 and Octavo's datasheet level. |

Copper weight (1 oz inner, previously mis-stated as 0.5 oz) and the finished
size (79.4 × 119.4 mm at the Edge_Cuts centreline) were corrected earlier and
now agree with the `.gbrjob`.

## Still open — needs a KiCad layout session

**A. U7 re-route — blocking.** The DRT-3 land is ~1.0 × 1.0 mm against
SOT-23-3's 2.9 × 1.9 mm, so the old routing no longer lands on the pads. DRC
now reports 6 errors and 2 unconnected, all inside the U7 pocket around
(25.0, 3.2) mm: the old `/USB_DP_CONN` tracks run across the new pad 2 and
short D+ to D−. Delete those stubs and re-route. Do this together with B.

**B. USB D+/D− cleanup — high.** `R1`/`R2` are 0 Ω in series with the pair,
splitting each leg into `/USB_DP` + `/USB_DP_CONN`, and both nets sit on net
class `Default` with no differential-pair or impedance rules. Remove R1/R2,
make each leg one net, add a diff-pair class, and route the pair over a
continuous reference plane from J1 through U7 to U1.

**C. BQ24074 input current limit — FIXED 2026-08-18.** `EN1` was tied to
`AUX_3V3`, a rail that only exists after U3 and U4 have come up, so at plug-in
with no battery EN2:EN1 read 0:0 = USB100 and the 100 mA limit could not carry
boot inrush — OUT sagged, U4 dropped out, EN1 fell again. The EN1 strap label
now reads `VBUS`, giving EN2:EN1 = 0:1 = USB500 from the instant power appears,
independent of any downstream rail. Verified in the netlist: `U2.6 EN1 ->
/VBUS`. If drawing 500 mA before enumeration is a concern for your hosts,
switch to ILIM mode (EN2 high, EN1 low) and set the limit with the ILIM
resistor instead.

**D. RECOVERY sits on JTAG TDI — delete it.** `/RECOVERY` connects `J7` pin 1
to U1 ball `C1`, whose pin function in the netlist is literally `TDI`. It is
also redundant: SYSBOOT[4:0] = `11000` already puts USB0 in the ROM's boot
fall-through, so pulling the SD card drops the ROM to UART0 then USB0 with no
strap involved, and `J6` gives UART pads as a second route. A redundant
function is consuming the only JTAG ball on the board. Remove `J7` and spend
the pins on E. Not done here: deleting `J7` removes a placed footprint and
leaves its routing dangling, so it belongs in the same layout session as A.

**E. No JTAG — high for a first prototype.** `TDI` is the only JTAG ball
connected anywhere in the netlist; there is no TCK, TMS, TDO or TRSTn, and the
one JTAG pin present has been consumed by RECOVERY. `J6` gives UART test pads,
which is the only debug access on the board. Add JTAG pads before committing
to first silicon.

**F. SYS_5V bulk capacitance — verify, and probably a sourcing failure.**
`C7` and `C8` are **22 µF/10 V in 0402**, with `C10`/`C20` 10 µF and `C14`
4.7 µF also 0402. A 22 µF 0402 is barely a purchasable part, and an 0402 X5R at
5 V bias loses most of its nominal value. Re-check effective capacitance under
DC bias against the OSD335x requirement and move the bulk to 0805 or larger.

**G. J5 pinout is unverified.** The review flagged pin 35 as needing `AUX_3V3`
rather than `GND` (currently pins 3 and 34 are `AUX_3V3`; 4, 35 and 36 are
`GND`). This could not be checked here: every J5 symbol pin is a generic
`Pin_N` with no function name, so the design captures no pinout for the display
at all. Get the EA TFT020-23AINN / WF030-39S datasheet, name the symbol pins
from it, and re-verify the whole connector — not just pin 35.

---

# Second audit — 2026-08-18

Systematic pass over the regenerated netlist: rail-by-rail decoupling, every
footprint against its MPN, SYSBOOT decode, OSD335x mandatory ties, BOM/CPL
coverage, and every net whose only nodes are U1.

## New findings

**H. `/OSD_3V3A` has 14 U1 balls and zero capacitors — highest-value new find.**
The module's main 3.3 V output is brought out on fourteen balls with no bypass
anywhere on the net. Same pattern on `/OSD_1V8` (8 balls, 0 caps),
`/OSD_3V3AUX` (2, 0), `/OSD_RTC_1V8` (2, 0), and `/ADC_VREFP` (0). `/OSD_3V3B`
has four balls sharing one 100 nF. The OSD335x-SM bypasses its PMIC outputs
internally, so some of this may be legal — but 14 balls feeding external loads
with nothing local is not. Check each rail against Octavo's datasheet and add
per-ball 100 nF plus bulk where the rail leaves the module.

**I. `VIN_BAT` (P8/R8/T8) is a power input tied only to `PMIC_BAT_SENSE`.**
Nothing sources it. The board really is powered — `VIN_AC` (P10/R10/T10) sits on
`SYS_5V` from U3 — and `VIN_USB` (P9/R9/T9) is deliberately grounded to select
the power mode. But a floating `W`-class power input needs Octavo's explicit
blessing. Confirm whether VIN_BAT should be grounded or tied to `SYS_BAT`.

**J. Thirteen bulk ceramics ≥ 4.7 µF are in 0402, five of them 22 µF.**
`C107`/`C108`/`C109` are 3 × 22 µF/10 V on `/OSD_SYS` — that is the 66 µF the
first review flagged (it is on SYS_VOUT/`OSD_SYS`, not `SYS_5V`; `SYS_5V`
separately carries `C7`/`C8` at 22 µF/10 V plus 10 µF and 4.7 µF 0402s).
A 22 µF 10 V 0402 is at the edge of what exists, and an 0402 X5R at 5 V bias
keeps a fraction of its nominal. Re-spec to 0805 and recompute under bias.

**K. `L2` footprint `L_APV_ANR3012` against MPN `XFL3012-222MEB`.** A generic
3012 land (0.8 × 2.7 mm pads at ±1.15 mm), not Coilcraft's own pattern. KiCad
ships no XFL3012 footprint, and guessing a land pattern is the exact error
being fixed at U7, so this is left flagged rather than swapped. Check the
Coilcraft drawing; the sizes are close enough that it may well pass.

**L. `J3` (power switch pads) has no BOM line — FIXED 2026-08-18.** Added as
off-board row 59, matching how `J2` and `J4` are handled.

## Checked and correct

Recorded so these are not re-litigated:

- **SYSBOOT decodes to 0x4018.** RN7–RN10 give SYSBOOT[15:14] = `01` = 24 MHz,
  matching Y1, and SYSBOOT[4:0] = `11000`. Verify the boot-order list against
  the AM335x TRM, but on the BBB convention that is MMC1 → MMC0 → UART0 → USB0.
- **The four "reference ties" are right.** `PMIC_POWER_EN`→`PMIC_PWR_EN`,
  `PMIC_PGOOD`→`PWRONRSTN`, `PMIC_LDO_PGOOD`→`RTC_PWRONRSTN` are output→input
  loopbacks inside the module — that *is* the reference connection, not a
  floating island, and they need no external pull-ups.
- **`LCD_D16`/`D17` on `GPMC_AD15`/`GPMC_AD14` is correct** AM335x mode-1 pin
  muxing, not a misconnection.
- **Battery sense is in range.** R33 1 M / R34 330 k divides 4.2 V to 1.04 V
  into AIN0, inside the 1.8 V ADC range.
- **`R4` DNP on `USB_VBUSDET` is deliberate** per Octavo UB1 — USB0_VBUS is
  meant to see 5 V.
- **Every other footprint matches its MPN**: U2 RGT = VQFN-16 3×3, U4 DSG =
  WSON-8 2×2, U5 DRV = WSON-6 2×2, U6 = TQFN-16 3×3, D3 = SOD-123F, J9 and J1
  match their Molex part numbers.
- **`exclude_from_pos_files` is correct everywhere else** — the other nine are
  three DNP resistors and six bare-pad pseudo-connectors with no part to place.

---

# Third pass — 2026-08-18

Prompted by "is there anything else". There was.

**M. `U4` output voltage is set by part number, not by a divider — verify first.**
`TPS62162DSG` has no feedback network: pin 6 `VOS` ties straight to `AUX_3V3`,
which means it is a fixed-output variant and the rail voltage is whatever the
suffix says. Within the TPS6216x family the `-2` suffix is 1.8 V in some
groupings and 3.3 V in others, and I cannot resolve it without the datasheet.
If it is the 1.8 V part, `AUX_3V3` is not 3.3 V, and the display rail, the
`TFT_RESET` pull-up, and the J5 supply pins are all wrong. Check this before
anything else on this list.

**N. `L1` is 0.47 µH on a TPS63802 buck-boost.** `L1` (`XFL4015-471ME`) sits on
`/BB_L1`–`/BB_L2` between U3 pins 9 and 7. TI's recommended inductor for the
TPS63802 is around 1.5 µH. 0.47 µH would mean high ripple current, early
current-limit, and poor efficiency on the rail that feeds the SoC. Verify
against the datasheet's inductor-selection table.

**O. The board has no mounting holes.** `pokeboy-hw-NPTH.drl` is empty, and the
plated drill contains only 0.20/0.25/0.60/0.85 mm — vias and component holes.
Nothing mechanical. Confirm the enclosure really is intended to retain the board
by capture alone, given a 0.80 mm panel carrying a display, battery and speaker.

**P. `Y1` footprint does not match its library copy.** DRC reports
`lib_footprint_mismatch` on `CRYSTAL_5X3.2MM` — the instance on the board has
diverged from `Pokeboy.pretty`. Since Y1 sets the 24 MHz that SYSBOOT[15:14]
selects, confirm which copy is right.

**Q. 25 silkscreen violations never reviewed.** Full DRC (all severities) is 42
violations: 15 `silk_overlap`, 10 `silk_over_copper`, 5 `text_height`, 4
`text_thickness`, plus the 6 U7 errors, 1 `track_dangling` and the Y1 mismatch.
Silk over copper matters where it lands on an exposed pad. These were referred
to earlier as "36 non-blocking warnings" and never looked at.

## Not audited at all

Neither pass touched any of this. It is where the next real problems are:

- **Layout quality.** Only DRC has been run. Nobody has looked at BGA escape
  routing, via-in-pad, ground-plane splits and return paths, decoupling
  placement distance from the balls, or crystal keepout and guarding.
- **AM335x pin muxing.** Whether every peripheral assignment is simultaneously
  legal in one mux configuration has not been checked — a classic source of
  "this pin cannot do that in that mode".
- **Power budget and thermals.** Total current against U3's capability, battery
  life, and an OSD335x dissipating into a 0.80 mm board with no heatsink.
- **Stencil and paste** apertures for the 256-ball BGA.
- **Mechanical fit** against the enclosure — button, display and connector
  positions.
- **ESD/EMI** on exposed connectors beyond the USB pair.

---

# Datasheet pass — 2026-08-18

Datasheets downloaded and read. Four earlier findings were wrong and are
retracted; one was right and is now fixed; one is sharpened with a hard number.

## Fixed

**G. J5 pin 35 — CONFIRMED AND FIXED.** The original review was right. In the
EA TFT020-23AI datasheet, pin 35 is `IM3` (Interface Mode 3) and the RGB column
requires **VDD**. The board had pins 34/35/36 = VDD/GND/GND, which matches none
of the four interface modes — RGB wants VDD/VDD/GND, 8-bit wants GND/GND/RD,
16-bit GND/VDD/RD, SPI VDD/VDD/GND. The panel would not have come up in RGB.
The pin 35 label is now `AUX_3V3`; verified in the netlist as `J5.35 ->
/AUX_3V3`.

The rest of the connector was checked pin by pin against the RGB column and is
correct: 1/2 LED−/LED+, 3 VDD, 4 GND, 5–10 → B2–B7, 11–16 → G2–G7, 17–22 →
R2–R7 (correct RGB666 ordering for AM335x `LCD_DATA[17:0]`), 23–26
DOTCLK/DE/HSYNC/VSYNC, 29/31/32/33 SDA/SCL/DC/RESET, 36 RDX = GND, and the
touch pins 37–39 correctly left unconnected.

## Retracted — these were not bugs

**M. `U4` output voltage — NOT a bug.** TI SLVSAM2E §5 Device Voltage Options:
`TPS62162` = **3.3 V**, WSON(8). (`TPS62160` adjustable, `TPS62161` 1.8 V,
`TPS62163` 5.0 V.) `AUX_3V3` is correct and DSG matches the footprint.

**N. `L1` 0.47 µH — NOT a bug.** 0.47 µH is the TPS63802's specified inductor,
listed as a headline feature ("Small 0.47-µH inductor") and the only row in
Table 10-1's inductor/capacitor matrix. The value is right.

**H. Missing rail decoupling — NOT a bug.** OSD335x-SM datasheet §2.1: "The
OSD335x-SM does not require any external decoupling / bypass capacitors in most
applications." The rails carry integrated bulk inside the module (SYS_VDD1 2.2
µF, SYS_VDD2 2.2 µF, SYS_VDD3 10 µF, SYS_VDD_1P8V 10 µF, SYS_RTC_1P8V 10 µF).
`OSD_3V3A` with 14 balls and no external caps is legal.

**I. `VIN_BAT` — NOT a bug, it is the required connection.** §7.1.3: "When
VIN_BAT is not used, it must be connected to PMIC_BAT_SENSE." That is exactly
what the board does. §7.1.2 likewise says an unused `VIN_USB` "should be
connected to DGND", which the board also does. Both ties are per spec.

## Sharpened

**J/F. SYS_VOUT bulk capacitance — still real, now with a number.** §2.1.1 and
Table 2-1: SYS_VOUT is the one rail that **requires additional external bulk,
~50 µF**, to avoid in-rush/power-up problems. The board provides `C107`/`C108`/
`C109` = 3 × 22 µF/10 V **in 0402**. Nominal 66 µF clears 50 µF; effective
capacitance at 5 V bias in an 0402 will not. Octavo's own footnote anticipates
"20% and −50%" derating, and an 0402 X5R at 5 V typically loses more than that.
Move this bulk to 0805 or larger and recompute against the 50 µF floor. This is
the item the first review flagged, and it is the one that survived.

**K. `L2` land pattern — low risk, still unverified.** The XFL3012 datasheet
confirms a 3.0 × 3.0 mm body, consistent with the 3.1 × 2.7 mm envelope of the
`L_APV_ANR3012` land in use. Coilcraft publishes the recommended pattern only as
a drawing, so exact pad dimensions could not be extracted. Low risk; confirm
against the drawing before release.

**MSL 4 is confirmed**, not assumed — OSD335x-SM datasheet Rev. 12 states it
directly. `FAB_NOTES.txt` and `PCBWAY_ORDER.md` now say so definitively.

---

# BOM review — 2026-08-18

**S. `C7 C8 C107 C108 C109` specified a part number that does not exist.**
The BOM called for Murata `GRM155R61A226ME11D` (22 µF, 10 V, 0402). Murata's
`GRM155` case is the 0.5 mm-thick 0402 and is not made in 22 µF/10 V. The real
part is **`GRM158R61A226ME15D`** — `GRM158` is the taller 0402 (≈0.8 mm), widely
stocked at DigiKey, Farnell, Newark and JLCPCB. On full turnkey this would have
come back as a sourcing query or, worse, been silently substituted. MPN
corrected in the BOM. **Note the height change** — GRM158 is thicker than
GRM155, which eats into the enclosure clearance budget.

This does **not** close the capacitance problem. Octavo Table 2-1 requires
~50 µF of *additional external* bulk on SYS_VOUT. Three 22 µF 0402 parts are
66 µF nominal but nowhere near 50 µF effective at 5 V bias, whichever case code
is fitted. The bank still needs re-speccing to 0805 or larger.

## BOM/CPL structural checks — all clean

Verified mechanically against the schematic and placement file:

- 59 rows, no gaps or duplicates in item numbering, no duplicate designators.
- Every row's `Qty` matches its designator count; every row has an MPN.
- Every SMT designator appears in the CPL, and every CPL entry has an SMT BOM
  row — the two files now agree exactly in both directions.
- All three DNP parts (`R4`, `R9`, `R19`) are correctly absent from the CPL.
- The only schematic references without BOM rows are `J6`, `J7` and `J8` — bare
  test and short pads with no part to fit, which is correct.

---

# PROTO-B1 — all findings closed (2026-08-18)

Every item above is now fixed in the source, or explicitly accepted:

| Item | Resolution |
|------|-----------|
| A — U7 re-route | Done. DRT-3 pocket fully re-routed; D+ dives to the In1 network below pad 1, D− runs F.Cu with one via onto the In1 spine. |
| B — USB pair | R1/R2 deleted, `USB_DP`/`USB_DM` are each one continuous net J1 → U7 → U1; stale stubs and redundant vias removed. Impedance control remains declined for this prototype (short traces, order note stands). |
| C — BQ24074 | EN1 on VBUS; USB500 from plug-in. |
| D — RECOVERY | J7 kept as a bare-pad **TDI test point**, net renamed `JTAG_TDI`; the misleading RECOVERY function is gone (SYSBOOT already falls through to USB0 for recovery). |
| E — JTAG | **Accepted limitation**: TDI pad only. Full JTAG needs BGA escape routing under U1 — deferred to PROTO-C, recorded in FAB_NOTES. |
| F/J — SYS_VOUT bulk | C107/C108/C109 now 22 µF/10 V **0805** (GRM21BR61A226ME44L) at 2.2 mm pitch, rail extended, zones refilled. C7/C8/C11 stay 0402 with corrected GRM158 MPNs (same land, taller body). |
| G — J5 pin 35 | Fixed to AUX_3V3 (IM3=VDD, RGB mode); full connector verified against datasheet. |
| K — L2 land | XFL3012 body 3.0×3.0 confirmed against the 3012 land in use; low risk, accepted. |
| M, N, H, I | Retracted — datasheets show them correct as designed. |
| O — mounting holes | **Accepted**: enclosure retains the board by capture (LEGO-plate cavity design); no holes added. |
| P — Y1 mismatch | Footprint resynced from `Pokeboy.pretty`; ref text normalized. |
| Q — silkscreen | All 25+ silk warnings cleared: text sizes to spec, refs relocated or hidden where they sat under U1/inside dense clusters, module labels moved off copper. |
| S — BOM MPNs | Nonexistent GRM155 22 µF parts replaced with real GRM158 (0402) and GRM21B (0805) parts. |

**Final verification: DRC 0 errors / 0 warnings / 0 unconnected. ERC 0 errors
(4 library-cache warnings only). Revision bumped to PROTO-B1 on both silks and
the schematic title block.**
